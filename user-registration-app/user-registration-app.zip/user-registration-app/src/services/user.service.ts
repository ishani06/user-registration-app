import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from 'src/models/user';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';


@Injectable()
export class UserService {

    baseUrl = environment.baseUrl;
    apiURL = this.baseUrl + 'userservice';

    constructor(private http: HttpClient) { }

    register(user: User) : Observable<any>{
        return this.http.post(this.apiURL + '/registerUser', user);
    }
}