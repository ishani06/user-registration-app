import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable()
export class AuthenticationService {

    baseUrl = environment.baseUrl;
    apiURL = this.baseUrl + 'userservice';
    
    constructor(private http: HttpClient) { }

    login(username: string, password: string) {
        return this.http.post<any>(this.apiURL + '/validateUser', { username: username, password: password })
            .pipe(map(user => {
                if (user) {
                    sessionStorage.setItem('currentUser', JSON.stringify(user));
                }
                return user;
            }));
    }

    logout() {
        sessionStorage.removeItem('currentUser');
    }
}