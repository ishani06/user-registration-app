import {
  Component,
  OnInit,
  OnDestroy
} from '@angular/core';
import {
  Router,
  ActivatedRoute
} from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import {
  AuthenticationService
} from 'src/services/authentication.service';
import { MatDialog } from '@angular/material';
import { HttpErrorResponse } from '@angular/common/http';
import { ErrorDialogComponent } from '../widgets/error-dialog/error-dialog.component';
import { ConfirmationDialogComponent } from '../widgets/confirmation-dialog/confirmation-dialog.component';
import { Subscription } from 'rxjs';

@Component({
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {

  loginForm: FormGroup;
  loading = false;
  submitted = false;
  isValidLogin = false;
  returnUrl: string;
  subscription: Subscription;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private authenticationService: AuthenticationService,
    private dialog: MatDialog) { }
 
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
    this.authenticationService.logout();
  }  

  onSubmit() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.loading = true;
    this.subscription = this.authenticationService.login(this.loginForm.controls.username.value, this.loginForm.controls.password.value).subscribe(
      data => {
        if(data!=null){
          this.router.navigate(['/']);
        }
        else {
          this.isValidLogin = true;
        }
      },(err: HttpErrorResponse) => {
        this.loading = false;
        this.dialog.open(ErrorDialogComponent, {
          disableClose: true,
          data: err.error.message
        });
      });
  }

  ngOnDestroy(): void {
    if(this.subscription != undefined)
      this.subscription.unsubscribe();
  }

}
