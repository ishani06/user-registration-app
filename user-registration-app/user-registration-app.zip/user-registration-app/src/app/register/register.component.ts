import {
  Component,
  OnInit,
  OnDestroy
} from '@angular/core';
import {
  Router
} from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import {
  UserService
} from 'src/services/user.service';
import { MatDialog } from '@angular/material';
import { ConfirmationDialogComponent } from '../widgets/confirmation-dialog/confirmation-dialog.component';
import { HttpErrorResponse } from '@angular/common/http';
import { ErrorDialogComponent } from '../widgets/error-dialog/error-dialog.component';
import { Subscription } from 'rxjs';

@Component({
  templateUrl: 'register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit, OnDestroy {
  registerForm: FormGroup;
  loading = false;
  submitted = false;
  subscription: Subscription;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private userService: UserService,
    private dialog: MatDialog) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  onSubmit() {
    this.submitted = true;
    if (this.registerForm.invalid) {
      return;
    }
    this.loading = true;
    this.subscription = this.userService.register(this.registerForm.value).subscribe(
      data => {
        if(data!=null) {
          const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            disableClose: true,
            data: 'Registration Successful'
          });
          dialogRef.afterClosed().subscribe(()=>{this.router.navigate(['/login'])});
        }
      },(err: HttpErrorResponse) => {
        this.loading = false;
        this.dialog.open(ErrorDialogComponent, {
          disableClose: true,
          data: err.error.message
        });
      });
  }

  ngOnDestroy(): void {
    if(this.subscription != undefined)
      this.subscription.unsubscribe();
  }
}
